import { config } from "dotenv"
config()
import { MongoClient, ObjectId } from "mongodb";

const DB_URI = process.env.DB_URI;
const DB_NAME = process.env.DB_NAME;

let client;

const connectDB = async () => {
    if (!client) {
        client = new MongoClient(DB_URI);
        await client.connect();
    }
    return client;
};

export const handler = async (event) => {
    const client = await connectDB();
    const db = client.db(DB_NAME);

    for (const record of event.Records) {
        try {
            const key = record?.s3?.object?.Key;
            if (!key) continue;

            let fullKey = decodeURIComponent(key.replace(/\+/g, " "));
            console.log("S3 key:", fullKey);

            const parts = fullKey.split("/");

            /*
              Echo / users / userId / profile / file.jpg
              Echo / users / UserId / cover / file.jpg
            */

            const collectionName = parts[1]; // users | posts
            const documentId = parts[2];
            const fieldType = parts[3]; // profile | image

            if (!collectionName || !documentId || !fieldType) {
                console.log("Invalid key format:", fullKey);
                continue;
            }

            const collection = db.collection(collectionName);

            // mapping للفيلد
            let updateField;

            switch (fieldType) {
                case "profile":
                    updateField = "profileImage";
                    break;
                case "cover":
                    updateField = "coverImage";
                    break;
                default:
                    updateField = "file";
            }

            const result = await collection.updateOne(
            { _id: new ObjectId(documentId) },
                {
                    $set: {
                        [updateField]: fullKey,
                        updatedAt: new Date(),
                    },
                }
            );

            console.log({
                collectionName,
                documentId,
                updateField,
                matched: result.matchedCount,
                modified: result.modifiedCount,
            });

        } catch (error) {
            console.error("Lambda error:", error);
        }
    }

    return { statusCode: 200 };
};